import React, { useEffect, useMemo, useRef, useState } from "react";
import { io } from "socket.io-client";
import { useNavigate } from "react-router-dom";
import Nav from "../components/Nav.jsx";
import { getSystemCheckPassed, getToken, setSystemCheckPassed } from "../lib/auth.js";
import { setLastCall } from "../lib/lastCall.js";

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || "http://localhost:3001";

function parseIceServers() {
  const raw = import.meta.env.VITE_ICE_SERVERS;
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export default function Call() {
  const navigate = useNavigate();

  const remoteAudioRef = useRef(null);

  const socketRef = useRef(null);
  const pcRef = useRef(null);
  const localStreamRef = useRef(null);
  const audioContextRef = useRef(null);
  const workletNodeRef = useRef(null);
  const callRef = useRef({
    callId: null,
    role: null,
    peerId: null,
    peerUserId: null,
    peerUsername: null,
  });

  const [connected, setConnected] = useState(false);
  const [status, setStatus] = useState("idle");

  const [callId, setCallId] = useState(null);
  const [role, setRole] = useState(null);
  const [peerId, setPeerId] = useState(null);
  const [peerUserId, setPeerUserId] = useState(null);
  const [peerUsername, setPeerUsername] = useState(null);

  const [callEndsInSec, setCallEndsInSec] = useState(null);

  const iceServers = useMemo(() => parseIceServers(), []);

  function log(s) {
    setStatus(s);
  }

  async function ensureLocalStream() {
    if (localStreamRef.current) return localStreamRef.current;
    localStreamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
    return localStreamRef.current;
  }

  async function startRecording(activeCallId) {
    const socket = socketRef.current;
    const stream = localStreamRef.current;
    if (!socket || !stream || !activeCallId) return;

    if (audioContextRef.current) return;

    const ctx = new AudioContext();
    audioContextRef.current = ctx;
    await ctx.audioWorklet.addModule("/pcm-worklet.js");

    const source = ctx.createMediaStreamSource(stream);
    const workletNode = new AudioWorkletNode(ctx, "pcm-processor");
    workletNodeRef.current = workletNode;

    const gain = ctx.createGain();
    gain.gain.value = 0;

    workletNode.port.onmessage = (e) => {
      const s2 = socketRef.current;
      if (!s2) return;
      s2.emit("record_chunk", e.data);
    };

    source.connect(workletNode);
    workletNode.connect(gain);
    gain.connect(ctx.destination);

    socket.emit("record_start", {
      callId: activeCallId,
      sampleRate: ctx.sampleRate,
      channels: 1,
    });
  }

  function stopRecording() {
    const socket = socketRef.current;
    try {
      if (socket) socket.emit("record_stop");
    } catch {
    }

    try {
      if (workletNodeRef.current) workletNodeRef.current.disconnect();
    } catch {
    }

    try {
      if (audioContextRef.current) audioContextRef.current.close();
    } catch {
    }

    workletNodeRef.current = null;
    audioContextRef.current = null;
  }

  async function createPeerConnection() {
    if (pcRef.current) return pcRef.current;

    const pc = new RTCPeerConnection({ iceServers });
    pcRef.current = pc;

    pc.onicecandidate = (ev) => {
      const socket = socketRef.current;
      const { callId: activeCallId, peerId: activePeerId } = callRef.current;
      if (!ev.candidate || !socket || !activeCallId || !activePeerId) return;
      socket.emit("signal", {
        callId: activeCallId,
        to: activePeerId,
        data: { type: "ice", candidate: ev.candidate },
      });
    };

    pc.ontrack = (ev) => {
      const [stream] = ev.streams;
      if (stream && remoteAudioRef.current) {
        remoteAudioRef.current.srcObject = stream;
      }
    };

    const stream = await ensureLocalStream();
    for (const track of stream.getTracks()) {
      pc.addTrack(track, stream);
    }

    return pc;
  }

  async function maybeMakeOffer(activeCallId, activePeerId, roleValue) {
    if (roleValue !== "offerer") return;

    const pc = await createPeerConnection();
    const offer = await pc.createOffer({ offerToReceiveAudio: true });
    await pc.setLocalDescription(offer);

    const socket = socketRef.current;
    socket.emit("signal", {
      callId: activeCallId,
      to: activePeerId,
      data: { type: "offer", sdp: pc.localDescription },
    });
  }

  async function onSignal(data) {
    const pc = await createPeerConnection();

    const { callId: activeCallId, peerId: activePeerId } = callRef.current;

    if (data.type === "offer") {
      await pc.setRemoteDescription(data.sdp);
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      socketRef.current.emit("signal", {
        callId: activeCallId,
        to: activePeerId,
        data: { type: "answer", sdp: pc.localDescription },
      });
      return;
    }

    if (data.type === "answer") {
      await pc.setRemoteDescription(data.sdp);
      return;
    }

    if (data.type === "ice") {
      try {
        await pc.addIceCandidate(data.candidate);
      } catch {
      }
    }
  }

  function cleanupCallUi() {
    stopRecording();

    try {
      if (pcRef.current) pcRef.current.close();
    } catch {
    }
    pcRef.current = null;

    if (remoteAudioRef.current) remoteAudioRef.current.srcObject = null;

    callRef.current = {
      callId: null,
      role: null,
      peerId: null,
      peerUserId: null,
      peerUsername: null,
    };

    setCallId(null);
    setRole(null);
    setPeerId(null);
    setPeerUserId(null);
    setPeerUsername(null);
    setCallEndsInSec(null);
  }

  async function connectSocket() {
    const token = getToken();
    if (!token) {
      navigate("/login");
      return;
    }

    const socket = io(BACKEND_URL, {
      auth: { token },
    });
    socketRef.current = socket;

    socket.on("connect", () => {
      setConnected(true);
      log("connected");
      const passed = getSystemCheckPassed();
      socket.emit("system_check_status", { passed });
    });

    socket.on("disconnect", () => {
      setConnected(false);
      log("disconnected");
      cleanupCallUi();
    });

    socket.on("queue", ({ status }) => {
      log(`queue: ${status}`);
    });

    socket.on("matched", async (payload) => {
      callRef.current = {
        callId: payload.callId,
        role: payload.role,
        peerId: payload.peerId,
        peerUserId: payload.peerUserId,
        peerUsername: payload.peerUsername,
      };

      setCallId(payload.callId);
      setRole(payload.role);
      setPeerId(payload.peerId);
      setPeerUserId(payload.peerUserId);
      setPeerUsername(payload.peerUsername);

      setLastCall({
        callId: payload.callId,
        peerUserId: payload.peerUserId,
        peerUsername: payload.peerUsername,
      });

      log("matched");

      await ensureLocalStream();
      await createPeerConnection();
      await startRecording(payload.callId);

      const endAt = Date.now() + 20 * 60 * 1000;
      const timer = setInterval(() => {
        const sec = Math.max(0, Math.ceil((endAt - Date.now()) / 1000));
        setCallEndsInSec(sec);
      }, 500);
      setCallEndsInSec(20 * 60);
      socket.once("call_ended", () => clearInterval(timer));

      if (payload.role === "offerer") {
        await maybeMakeOffer(payload.callId, payload.peerId, payload.role);
      }
    });

    socket.on("signal", async ({ data }) => {
      try {
        await onSignal(data);
      } catch {
      }
    });

    socket.on("peer_left", ({ reason }) => {
      log(`peer_left: ${reason}`);
      cleanupCallUi();
    });

    socket.on("call_ended", ({ callId: endedId, reason, peerUserId: p }) => {
      log(`call_ended: ${reason}`);

      const peerInfoBeforeCleanup = callRef.current;
      cleanupCallUi();
      try {
        socket.disconnect();
      } catch {
      }
      if (endedId) {
        setLastCall({
          callId: endedId,
          peerUserId: p || peerInfoBeforeCleanup.peerUserId,
          peerUsername: peerInfoBeforeCleanup.peerUsername,
        });
      }
      navigate("/feedback");
    });

    socket.on("error_message", ({ message }) => {
      log(`error: ${message}`);
      if (message === "system_check_required") {
        setSystemCheckPassed(false);
        navigate("/system-check");
      }
    });
  }

  useEffect(() => {
    if (!getSystemCheckPassed()) {
      log("system check not passed");
    }
  }, []);

  useEffect(() => {
    return () => {
      try {
        if (socketRef.current) socketRef.current.disconnect();
      } catch {
      }
      cleanupCallUi();
      try {
        if (localStreamRef.current) {
          localStreamRef.current.getTracks().forEach((t) => t.stop());
        }
      } catch {
      }
    };
  }, []);

  async function findMatch() {
    if (!socketRef.current || !connected) return;
    if (!getSystemCheckPassed()) {
      navigate("/system-check");
      return;
    }

    try {
      await ensureLocalStream();
    } catch {
      setSystemCheckPassed(false);
      navigate("/system-check");
      return;
    }

    socketRef.current.emit("system_check_status", { passed: true });
    socketRef.current.emit("find_match");
  }

  function hangup() {
    const socket = socketRef.current;
    if (!socket) return;
    socket.emit("hangup");
    cleanupCallUi();
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-blue-100">
      <Nav />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-center text-gray-800 mb-8">Voice Call</h1>

        <div className="bg-white rounded-2xl shadow-lg p-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-600 mb-1">Socket Status</div>
              <div className={`font-semibold ${
                connected ? "text-green-600" : "text-red-600"
              }`}>
                {connected ? "Connected" : "Disconnected"}
              </div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-600 mb-1">Call Status</div>
              <div className="font-semibold text-gray-800">{status}</div>
            </div>
          </div>

          <div className="flex flex-wrap gap-4 justify-center mb-8">
            <button
              onClick={connectSocket}
              disabled={connected}
              className="bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 disabled:bg-gray-400 transition-colors"
            >
              Connect
            </button>
            <button
              onClick={findMatch}
              disabled={!connected || !!callId}
              className="bg-green-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-700 disabled:bg-gray-400 transition-colors"
            >
              Find Random Match
            </button>
            <button
              onClick={hangup}
              disabled={!callId}
              className="bg-red-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-red-700 disabled:bg-gray-400 transition-colors"
            >
              Hangup
            </button>
          </div>

          <div className="bg-gray-900 rounded-lg p-4 mb-6">
            <audio ref={remoteAudioRef} autoPlay playsInline className="w-full" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-600">Call ID</div>
              <div className="font-mono text-gray-800">{callId || "-"}</div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-600">Role</div>
              <div className="font-semibold text-gray-800">{role || "-"}</div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-600">Peer</div>
              <div className="font-semibold text-gray-800">{peerUsername || peerId || "-"}</div>
            </div>
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="text-sm text-gray-600">Time Left</div>
              <div className="font-semibold text-gray-800">
                {callEndsInSec != null ? `${callEndsInSec}s` : "-"}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
