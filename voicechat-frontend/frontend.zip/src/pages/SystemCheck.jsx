import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import Nav from '../components/Nav.jsx';
import { setSystemCheckPassed } from '../lib/auth.js';

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || "http://localhost:3001";

const SystemCheck = () => {
    const navigate = useNavigate();

    // Steps: 'start', 'internet', 'mic', 'hearing'
    const [currentStep, setCurrentStep] = useState('start');

    // Internet Test State
    const [speed, setSpeed] = useState({ download: null, upload: null });
    const [internetStatus, setInternetStatus] = useState('idle'); // idle, checking, success, failed

    // Mic Test State
    const [micPermission, setMicPermission] = useState('pending');
    const [micVolume, setMicVolume] = useState(0);
    const [recognitionStatus, setRecognitionStatus] = useState('idle'); // idle, listening, success, failed
    const [transcript, setTranscript] = useState('');

    // Hearing Test State
    const [targetNumbers, setTargetNumbers] = useState('');
    const [userHearingInput, setUserHearingInput] = useState('');
    const [hearingStatus, setHearingStatus] = useState('idle'); // idle, playing, waiting, success, failed
    const [timeLeft, setTimeLeft] = useState(30);

    const audioContextRef = useRef(null);
    const analyserRef = useRef(null);
    const dataArrayRef = useRef(null);
    const streamRef = useRef(null);
    const recognitionRef = useRef(null);
    const utteranceRef = useRef(null);

    const MIC_TEST_SENTENCE = "SAM SITS SILENTLY WAITING FOR THE TEACHER TO CALL HIM SOON";

    useEffect(() => {
        return () => {
            stopMic();
            if (recognitionRef.current) recognitionRef.current.stop();
        };
    }, []);

    // --- STEP 1: INTERNET CHECK ---
    const startInternetCheck = async () => {
        setCurrentStep('internet');
        setInternetStatus('checking');
        setSpeed({ download: '...', upload: '...' });

        try {
            // 1. DOWNLOAD TEST
            // Using a ~5MB file from Wikimedia Commons (CORS enabled)
            const downloadUrl = 'https://upload.wikimedia.org/wikipedia/commons/2/2d/Snake_River_%285mb%29.jpg' + '?t=' + new Date().getTime();
            const startTimeDl = Date.now();
            const response = await fetch(downloadUrl);
            const blob = await response.blob();
            const endTimeDl = Date.now();

            const durationDl = (endTimeDl - startTimeDl) / 1000; // seconds
            const fileSizeBitsDl = blob.size * 8;
            const downloadSpeed = (fileSizeBitsDl / durationDl / 1000000).toFixed(1); // Mbps

            setSpeed(prev => ({ ...prev, download: downloadSpeed }));

            // 2. UPLOAD TEST
            // Create 2MB dummy file
            const uploadSize = 2 * 1024 * 1024;
            const dummyData = new Uint8Array(uploadSize);
            const uploadBlob = new Blob([dummyData]);

            const startTimeUl = Date.now();
            await fetch(BACKEND_URL + '/api/test/upload', {
                method: 'POST',
                body: uploadBlob,
                headers: { 'Content-Type': 'application/octet-stream' }
            });
            const endTimeUl = Date.now();

            const durationUl = (endTimeUl - startTimeUl) / 1000;
            const fileSizeBitsUl = uploadSize * 8;
            const uploadSpeed = (fileSizeBitsUl / durationUl / 1000000).toFixed(1); // Mbps

            setSpeed({ download: downloadSpeed, upload: uploadSpeed });

            // VALIDATION (Requirement: > 10 Mbps Download)
            if (parseFloat(downloadSpeed) >= 10) {
                setInternetStatus('success');
                setTimeout(() => startMicSetup(), 2000);
            } else {
                setInternetStatus('failed');
            }

        } catch (error) {
            console.error("Speed Test Failed:", error);
            setInternetStatus('failed');
            setSpeed({ download: 'Error', upload: 'Error' });
        }
    };

    // --- STEP 2: MIC CHECK ---
    const startMicSetup = () => {
        setCurrentStep('mic');
        // prompt for permission immediately
        initMic();
    };

    const initMic = async () => {
        try {
            const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
            streamRef.current = stream;
            setMicPermission('granted');

            const Ctx = window.AudioContext || window.webkitAudioContext;
            audioContextRef.current = new Ctx();
            analyserRef.current = audioContextRef.current.createAnalyser();
            const source = audioContextRef.current.createMediaStreamSource(stream);
            source.connect(analyserRef.current);
            analyserRef.current.fftSize = 256;
            dataArrayRef.current = new Uint8Array(analyserRef.current.frequencyBinCount);

            visualizeMic();
        } catch (err) {
            console.error(err);
            setMicPermission('denied');
        }
    };

    const visualizeMic = () => {
        if (!analyserRef.current) return;
        requestAnimationFrame(visualizeMic);
        analyserRef.current.getByteFrequencyData(dataArrayRef.current);
        const avg = dataArrayRef.current.reduce((a, b) => a + b) / dataArrayRef.current.length;
        setMicVolume(avg);
    };

    const startListening = () => {
        const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
        if (!SpeechRecognition) {
            alert("Speech Recognition not supported in this browser. Please use Chrome/Edge.");
            setRecognitionStatus('success'); // bypass for unsupported browsers
            setTimeout(() => startHearingTest(), 1000);
            return;
        }

        const recognition = new SpeechRecognition();
        recognitionRef.current = recognition;
        recognition.continuous = false;
        recognition.lang = 'en-US';
        recognition.interimResults = true;

        recognition.onstart = () => setRecognitionStatus('listening');

        recognition.onresult = (event) => {
            const currentTranscript = Array.from(event.results)
                .map(result => result[0].transcript)
                .join('')
                .toUpperCase();
            setTranscript(currentTranscript);

            // Strict exact match check
            // Removing special characters just in case, to compare only letters/spaces
            const cleanTranscript = currentTranscript.replace(/[^A-Z ]/g, '').trim();
            const cleanTarget = MIC_TEST_SENTENCE.replace(/[^A-Z ]/g, '').trim();

            if (cleanTranscript.includes(cleanTarget) || cleanTarget.includes(cleanTranscript) && cleanTranscript.length > cleanTarget.length * 0.8) {
                // Relaxed matching slightly to allow for partial starts if speech cuts in, but usually full match needed.
                // Ideally exact match as user requested.
                if (cleanTranscript === cleanTarget) {
                    recognition.stop();
                    setRecognitionStatus('success');
                    setTimeout(() => startHearingTest(), 1500);
                }
            }
            if (cleanTranscript === cleanTarget) {
                recognition.stop();
                setRecognitionStatus('success');
                setTimeout(() => startHearingTest(), 1500);
            }
        };

        recognition.onerror = (e) => {
            console.error(e);
            setRecognitionStatus('failed');
        };

        recognition.start();
    };

    const stopMic = () => {
        if (streamRef.current) {
            try {
                streamRef.current.getTracks().forEach(t => t.stop());
            } catch { }
        }
        if (audioContextRef.current) {
            try {
                audioContextRef.current.close();
            } catch { }
        }
    };

    // --- STEP 3: HEARING TEST ---
    const startHearingTest = () => {
        stopMic(); // stop mic before hearing test
        setCurrentStep('hearing');
        setHearingStatus('idle');

        // Generate random numbers: "555 666" format
        const p1 = Math.floor(100 + Math.random() * 900);
        const p2 = Math.floor(100 + Math.random() * 900);
        const code = `${p1} ${p2}`;
        setTargetNumbers(code);
    };

    const playNumbers = () => {
        setHearingStatus('playing');
        window.speechSynthesis.cancel(); // Clear previous

        // targetNumbers is "XXX YYY"
        const parts = targetNumbers.split(' '); // ["555", "666"]

        // Convert "555" -> "5 5 5" for distinct pronunciation called numbers
        const part1 = parts[0].split('').join(' ');
        const part2 = parts[1].split('').join(' ');

        const speak = (text, callback) => {
            const u = new SpeechSynthesisUtterance(text);
            utteranceRef.current = u;
            u.rate = 0.6;
            u.pitch = 1;
            u.onend = callback || null;
            u.onerror = (e) => {
                console.error("Speech error", e);
                setHearingStatus('failed');
            };
            window.speechSynthesis.speak(u);
        };

        // Speak Part 1
        speak(part1, () => {
            // 2 Seconds Silence
            setTimeout(() => {
                // Speak Part 2
                speak(part2, () => {
                    setHearingStatus('waiting');
                    setTimeLeft(30);
                });
            }, 2000);
        });
    };

    useEffect(() => {
        if (hearingStatus === 'waiting' && timeLeft > 0) {
            const timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
            return () => clearInterval(timer);
        } else if (hearingStatus === 'waiting' && timeLeft === 0) {
            setHearingStatus('failed');
            alert("Time's up!");
        }
    }, [hearingStatus, timeLeft]);

    const submitHearingCheck = () => {
        if (userHearingInput.trim() === targetNumbers.replace(/\s/g, '')) { // check without spaces usually easier
            setHearingStatus('success');
            setSystemCheckPassed(true);
            setTimeout(() => {
                navigate('/call');
            }, 2000);
        } else if (userHearingInput.trim() === targetNumbers) {
            setHearingStatus('success');
            setSystemCheckPassed(true);
            setTimeout(() => {
                navigate('/call');
            }, 2000);
        } else {
            alert("Incorrect. Please listen and try again.");
            setUserHearingInput('');
            // Optionally replay or fail logic?
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 relative overflow-hidden">
            {/* Decorative Background Elements */}
            <div className="absolute top-0 left-0 w-96 h-96 bg-purple-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob"></div>
            <div className="absolute top-0 right-0 w-96 h-96 bg-yellow-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-2000"></div>
            <div className="absolute -bottom-32 left-20 w-96 h-96 bg-pink-200 rounded-full mix-blend-multiply filter blur-3xl opacity-30 animate-blob animation-delay-4000"></div>

            <Nav />
            <div className="container mx-auto px-4 py-12 relative z-10">
                <div className="max-w-3xl mx-auto bg-white/70 backdrop-blur-xl rounded-3xl shadow-2xl border border-white/50 overflow-hidden transition-all duration-300">
                    <div className="p-8 md:p-12 text-center min-h-[500px] flex flex-col justify-center items-center">

                        {currentStep === 'start' && (
                            <div className="animate-fade-in space-y-8">
                                <div className="space-y-4">
                                    <h1 className="text-4xl md:text-5xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">
                                        System Check
                                    </h1>
                                    <p className="text-xl text-gray-600 max-w-lg mx-auto leading-relaxed">
                                        Ensuring your device is ready for the best voice experience. We'll verify your internet, microphone, and speakers.
                                    </p>
                                </div>
                                <button
                                    onClick={startInternetCheck}
                                    className="group relative inline-flex items-center justify-center px-8 py-4 text-lg font-bold text-white transition-all duration-200 bg-gradient-to-r from-purple-600 to-pink-600 rounded-full shadow-lg hover:shadow-purple-500/40 hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-purple-500"
                                >
                                    Start Test
                                    <svg className="w-5 h-5 ml-2 -mr-1 transition-transform group-hover:translate-x-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 7l5 5m0 0l-5 5m5-5H6"></path></svg>
                                </button>
                            </div>
                        )}

                        {currentStep === 'internet' && (
                            <div className="animate-fade-in w-full max-w-md space-y-8">
                                <h2 className="text-3xl font-bold text-gray-800">Internet Speed Test</h2>

                                {internetStatus === 'checking' && (
                                    <div className="flex flex-col items-center space-y-6">
                                        <div className="relative">
                                            <div className="w-20 h-20 border-4 border-purple-200 border-t-purple-600 rounded-full animate-spin"></div>
                                            <div className="absolute inset-0 flex items-center justify-center">
                                                <svg className="w-8 h-8 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 10V3L4 14h7v7l9-11h-7z"></path></svg>
                                            </div>
                                        </div>
                                        <div className="space-y-2">
                                            <p className="text-lg font-medium text-gray-700">Testing Connection...</p>
                                            <div className="text-sm text-gray-500 bg-gray-50 rounded-lg p-4 border border-gray-100 flex justify-between w-full">
                                                <span>Download: <span className="font-mono font-bold text-gray-800">{speed.download || '...'}</span> Mbps</span>
                                                <span>Upload: <span className="font-mono font-bold text-gray-800">{speed.upload || '...'}</span> Mbps</span>
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {internetStatus === 'success' && (
                                    <div className="space-y-8">
                                        <div className="grid grid-cols-2 gap-4">
                                            <div className="bg-green-50 p-6 rounded-2xl border border-green-100">
                                                <div className="text-3xl font-bold text-green-600 mb-1">{speed.download}</div>
                                                <div className="text-sm font-medium text-green-700 uppercase tracking-wide">Mbps Download</div>
                                            </div>
                                            <div className="bg-green-50 p-6 rounded-2xl border border-green-100">
                                                <div className="text-3xl font-bold text-green-600 mb-1">{speed.upload}</div>
                                                <div className="text-sm font-medium text-green-700 uppercase tracking-wide">Mbps Upload</div>
                                            </div>
                                        </div>
                                        <div className="flex items-center justify-center space-x-2 text-green-600 bg-green-50/50 py-2 rounded-full">
                                            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                                            <span className="font-bold text-lg">Excellent Connection!</span>
                                        </div>
                                    </div>
                                )}

                                {internetStatus === 'failed' && (
                                    <div className="space-y-6">
                                        <div className="bg-red-50 p-6 rounded-2xl border border-red-100">
                                            <div className="text-4xl font-bold text-red-600 mb-2">{speed.download} <span className="text-xl">Mbps</span></div>
                                            <p className="text-red-700 font-medium">Connection too slow</p>
                                            <p className="text-red-500 text-sm mt-1">Minimum 10 Mbps required</p>
                                        </div>
                                        <button
                                            onClick={startInternetCheck}
                                            className="px-8 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg transition-colors shadow-lg hover:shadow-red-500/30"
                                        >
                                            Retry Test
                                        </button>
                                    </div>
                                )}
                            </div>
                        )}

                        {currentStep === 'mic' && (
                            <div className="animate-fade-in w-full max-w-xl space-y-8">
                                <h2 className="text-3xl font-bold text-gray-800">Microphone Test</h2>

                                {micPermission === 'denied' ? (
                                    <div className="bg-red-50 border border-red-200 rounded-xl p-6 text-red-700">
                                        <p className="font-bold text-lg mb-2">Microphone Access Denied</p>
                                        <p>Please allow microphone access in your browser settings to continue.</p>
                                    </div>
                                ) : (
                                    <div className="space-y-8">
                                        {/* Volume Visualizer */}
                                        <div className="space-y-2">
                                            <div className="flex justify-between text-xs font-semibold text-gray-500 uppercase tracking-widest">
                                                <span>Mic Volume</span>
                                                <span>{Math.round(Math.min(micVolume, 100))}%</span>
                                            </div>
                                            <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden shadow-inner">
                                                <div
                                                    className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-100 ease-out"
                                                    style={{ width: `${Math.min(micVolume, 100)}%` }}
                                                ></div>
                                            </div>
                                        </div>

                                        <div className="space-y-4">
                                            <p className="text-gray-600 text-lg">Please read the following text clearly:</p>
                                            <div className="bg-slate-900 rounded-2xl p-8 shadow-xl border border-slate-700 relative group overflow-hidden">
                                                <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-pink-600/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                                                <h3 className="text-2xl md:text-3xl font-serif italic text-white leading-relaxed tracking-wide relative z-10 transition-transform duration-300 group-hover:scale-[1.02]">
                                                    "{MIC_TEST_SENTENCE}"
                                                </h3>
                                            </div>
                                        </div>

                                        <div className={`min-h-[3rem] text-lg font-medium transition-colors duration-300 ${recognitionStatus === 'listening' ? 'text-purple-600' : 'text-gray-400'
                                            }`}>
                                            {transcript || (recognitionStatus === 'listening' ? "Listening..." : "Click 'Start Speaking' to begin")}
                                        </div>

                                        <div className="flex justify-center">
                                            {recognitionStatus === 'idle' && (
                                                <button
                                                    onClick={startListening}
                                                    className="px-8 py-4 bg-purple-600 hover:bg-purple-700 text-white text-lg font-bold rounded-full shadow-lg hover:shadow-purple-500/40 transition-all hover:-translate-y-1 flex items-center space-x-2"
                                                >
                                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"></path></svg>
                                                    <span>Start Speaking</span>
                                                </button>
                                            )}

                                            {recognitionStatus === 'listening' && (
                                                <div className="flex items-center space-x-2 px-6 py-3 bg-red-50 text-red-600 rounded-full animate-pulse border border-red-100">
                                                    <div className="w-3 h-3 bg-red-600 rounded-full"></div>
                                                    <span className="font-bold">Listening...</span>
                                                </div>
                                            )}

                                            {recognitionStatus === 'success' && (
                                                <div className="flex items-center space-x-2 text-green-600 bg-green-50 px-6 py-3 rounded-full border border-green-200">
                                                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                                                    <span className="font-bold text-lg">Voice Verified!</span>
                                                </div>
                                            )}

                                            {recognitionStatus === 'failed' && (
                                                <button
                                                    onClick={startListening}
                                                    className="px-8 py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-full shadow-lg transition-all"
                                                >
                                                    Try Again
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                )}
                            </div>
                        )}

                        {currentStep === 'hearing' && (
                            <div className="animate-fade-in w-full max-w-md space-y-8">
                                <h2 className="text-3xl font-bold text-gray-800">Hearing Test</h2>
                                <p className="text-gray-600 text-lg">Listen to the numbers and type them below.</p>

                                {hearingStatus === 'idle' && (
                                    <button
                                        onClick={playNumbers}
                                        className="w-full py-4 bg-purple-600 hover:bg-purple-700 text-white text-xl font-bold rounded-xl shadow-lg hover:shadow-purple-500/30 transition-all flex items-center justify-center space-x-3"
                                    >
                                        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z"></path></svg>
                                        <span>Play Numbers</span>
                                    </button>
                                )}

                                {(hearingStatus === 'playing' || hearingStatus === 'waiting' || hearingStatus === 'failed') && (
                                    <div className="space-y-6">
                                        {hearingStatus === 'playing' && (
                                            <div className="text-purple-600 font-medium animate-pulse">Speaking numbers...</div>
                                        )}

                                        {hearingStatus === 'waiting' && (
                                            <div className="space-y-6">
                                                <input
                                                    type="text"
                                                    placeholder="e.g. 555 666"
                                                    value={userHearingInput}
                                                    onChange={(e) => setUserHearingInput(e.target.value)}
                                                    className="w-full text-center text-3xl font-bold tracking-widest py-4 border-2 border-purple-200 rounded-xl focus:border-purple-600 focus:ring-4 focus:ring-purple-100 outline-none transition-all placeholder-gray-300 text-gray-800"
                                                    autoFocus
                                                />
                                                <div className="flex items-center justify-between">
                                                    <div className={`font-mono font-bold text-lg ${timeLeft < 10 ? 'text-red-500' : 'text-gray-500'}`}>
                                                        Time: {timeLeft}s
                                                    </div>
                                                    <button
                                                        onClick={submitHearingCheck}
                                                        className="px-8 py-3 bg-purple-600 hover:bg-purple-800 text-white font-bold rounded-lg shadow-md transition-colors"
                                                    >
                                                        Submit
                                                    </button>
                                                </div>
                                            </div>
                                        )}

                                        {hearingStatus === 'failed' && (
                                            <div className="bg-red-50 border border-red-200 rounded-xl p-6 space-y-4">
                                                <p className="text-red-600 font-bold text-lg">Incorrect Details or Time's Up!</p>
                                                <button
                                                    onClick={startHearingTest}
                                                    className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-bold rounded-lg transition-colors"
                                                >
                                                    Retry
                                                </button>
                                            </div>
                                        )}
                                    </div>
                                )}

                                {hearingStatus === 'success' && (
                                    <div className="space-y-4 animate-bounce-short">
                                        <div className="w-24 h-24 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                                            <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7"></path></svg>
                                        </div>
                                        <h2 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-green-500 to-emerald-700">Passed!</h2>
                                        <p className="text-green-600 font-medium">Redirecting to call...</p>
                                    </div>
                                )}
                            </div>
                        )}
                    </div>
                </div>
            </div>

            <style>{`
                .animate-fade-in {
                    animation: fadeIn 0.6s cubic-bezier(0.16, 1, 0.3, 1);
                }
                @keyframes fadeIn {
                    from { opacity: 0; transform: translateY(20px); }
                    to { opacity: 1; transform: translateY(0); }
                }
                .animate-blob {
                    animation: blob 7s infinite;
                }
                .animation-delay-2000 {
                    animation-delay: 2s;
                }
                .animation-delay-4000 {
                    animation-delay: 4s;
                }
                @keyframes blob {
                    0% { transform: translate(0px, 0px) scale(1); }
                    33% { transform: translate(30px, -50px) scale(1.1); }
                    66% { transform: translate(-20px, 20px) scale(0.9); }
                    100% { transform: translate(0px, 0px) scale(1); }
                }
                .animate-bounce-short {
                    animation: bounceShort 1s ease-in-out;
                }
                @keyframes bounceShort {
                    0%, 100% { transform: translateY(0); }
                    50% { transform: translateY(-10px); }
                }
            `}</style>
        </div>
    );
};

export default SystemCheck;
