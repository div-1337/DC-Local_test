import React, { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import Nav from "../components/Nav.jsx";
import { apiPostJson } from "../lib/api.js";
import { clearLastCall, getLastCall } from "../lib/lastCall.js";

export default function Feedback() {
  const navigate = useNavigate();

  const last = useMemo(() => getLastCall(), []);
  const [ratingOverall, setRatingOverall] = useState(5);
  const [audioQuality, setAudioQuality] = useState(5);
  const [wouldTalkAgain, setWouldTalkAgain] = useState(true);
  const [notes, setNotes] = useState("");
  const [error, setError] = useState("");
  const [ok, setOk] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setError("");
    setOk(false);

    if (!last?.callId || !last?.peerUserId) {
      setError("missing_call_context");
      return;
    }

    try {
      await apiPostJson("/api/feedback", {
        callId: last.callId,
        toUserId: last.peerUserId,
        ratingOverall: Number(ratingOverall),
        audioQuality: Number(audioQuality),
        wouldTalkAgain: Boolean(wouldTalkAgain),
        notes,
      });
      setOk(true);
      clearLastCall();
      setTimeout(() => navigate("/history"), 800);
    } catch (e2) {
      setError(e2.message);
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 to-amber-100">
      <Nav />
      <div className="max-w-2xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-center text-gray-800 mb-8">Call Feedback</h1>
        
        <div className="bg-white rounded-2xl shadow-lg p-8">
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="text-sm text-gray-600 mb-1">Call Details</div>
            <div className="font-mono text-gray-800">
              Call ID: {last?.callId || "-"} | Peer: {last?.peerUsername || last?.peerUserId || "-"}
            </div>
          </div>

          <form onSubmit={submit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Overall Rating (1-5)
              </label>
              <input
                type="number"
                min="1"
                max="5"
                value={ratingOverall}
                onChange={(e) => setRatingOverall(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Audio Quality (1-5)
              </label>
              <input
                type="number"
                min="1"
                max="5"
                value={audioQuality}
                onChange={(e) => setAudioQuality(e.target.value)}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Would Talk Again?
              </label>
              <select 
                value={wouldTalkAgain ? "yes" : "no"} 
                onChange={(e) => setWouldTalkAgain(e.target.value === "yes")}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent"
              >
                <option value="yes">Yes</option>
                <option value="no">No</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Additional Notes
              </label>
              <textarea 
                value={notes} 
                onChange={(e) => setNotes(e.target.value)} 
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent resize-none"
                placeholder="Share your thoughts about the conversation..."
              />
            </div>

            <button
              type="submit"
              className="w-full bg-orange-600 text-white py-3 rounded-lg font-semibold hover:bg-orange-700 transition-colors"
            >
              Submit Feedback
            </button>

            {error ? (
              <div className="text-red-600 text-sm text-center bg-red-50 p-3 rounded-lg">
                {error}
              </div>
            ) : null}
            {ok ? (
              <div className="text-green-600 text-sm text-center bg-green-50 p-3 rounded-lg">
                Thanks! Saving...
              </div>
            ) : null}
          </form>
        </div>
      </div>
    </div>
  );
}
