import React, { useEffect, useState } from "react";
import Nav from "../components/Nav.jsx";
import { apiDownloadRecording, apiGet } from "../lib/api.js";

export default function History() {
  const [sessions, setSessions] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const res = await apiGet("/api/history");
        setSessions(res.sessions || []);
      } catch (e) {
        setError(e.message);
      }
    })();
  }, []);

  async function download(callId, fileName) {
    const blob = await apiDownloadRecording(callId, fileName);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-cyan-50 to-blue-100">
      <Nav />
      <div className="max-w-4xl mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-center text-gray-800 mb-8">Call History</h1>
        
        {error ? (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        ) : null}

        <div className="space-y-4">
          {sessions.map((s) => (
            <div
              key={s.callId}
              className="bg-white rounded-xl shadow-lg p-6 hover:shadow-xl transition-shadow"
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <div>
                  <div className="text-sm text-gray-600 mb-1">Peer</div>
                  <div className="font-semibold text-gray-800">
                    {s.peer?.username || "Unknown"}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-600 mb-1">Call ID</div>
                  <div className="font-mono text-gray-800">{s.callId}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-600 mb-1">Started</div>
                  <div className="text-gray-800">
                    {new Date(s.startedAt).toLocaleString()}
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-600 mb-1">Ended</div>
                  <div className="text-gray-800">
                    {s.endedAt ? new Date(s.endedAt).toLocaleString() : "-"}
                  </div>
                </div>
              </div>
              
              <div className="mb-4">
                <div className="text-sm text-gray-600 mb-1">End Reason</div>
                <div className="inline-block px-3 py-1 bg-gray-100 rounded-full text-sm">
                  {s.endReason || "Unknown"}
                </div>
              </div>

              {s.recordingFile ? (
                <button
                  onClick={() => download(s.callId, s.recordingFile)}
                  className="bg-cyan-600 text-white px-4 py-2 rounded-lg hover:bg-cyan-700 transition-colors flex items-center gap-2"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                  </svg>
                  Download My Recording
                </button>
              ) : (
                <div className="text-gray-500 text-sm bg-gray-50 px-3 py-2 rounded-lg inline-block">
                  Recording: not available
                </div>
              )}
            </div>
          ))}

          {sessions.length === 0 ? (
            <div className="bg-white rounded-xl shadow-lg p-12 text-center">
              <div className="text-gray-500 text-lg">No calls yet.</div>
              <div className="text-gray-400 text-sm mt-2">Start your first voice call to see it here!</div>
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
