import React from "react";
import { Navigate, Route, Routes } from "react-router-dom";
import Login from "./pages/Login.jsx";
import Signup from "./pages/Signup.jsx";
import SystemCheck from "./pages/SystemCheck.jsx";
import Call from "./pages/Call.jsx";
import History from "./pages/History.jsx";
import Feedback from "./pages/Feedback.jsx";
import { getToken } from "./lib/auth.js";

function RequireAuth({ children }) {
  const token = getToken();
  if (!token) return <Navigate to="/login" replace />;
  return children;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/signup" element={<Signup />} />

      <Route
        path="/system-check"
        element={
          <RequireAuth>
            <SystemCheck />
          </RequireAuth>
        }
      />

      <Route
        path="/call"
        element={
          <RequireAuth>
            <Call />
          </RequireAuth>
        }
      />

      <Route
        path="/feedback"
        element={
          <RequireAuth>
            <Feedback />
          </RequireAuth>
        }
      />

      <Route
        path="/history"
        element={
          <RequireAuth>
            <History />
          </RequireAuth>
        }
      />

      <Route path="/" element={<Navigate to="/system-check" replace />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
